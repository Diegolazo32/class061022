<?php
header('content-type: application/json; charset=utf-8');
echo $showUsers;
?>
