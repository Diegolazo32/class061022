<?php

class Users
{
    public function showUsers()
    {
        $json = file_get_contents('users.json');
        return $json;
    }

}

?>