<?php

class Universidad
{
    public function showUniversidad()
    {
        $Unidir = "Universidad.php";

        return $Unidir;
    }

}