<?php

class Hola
{

    public function showHola()
    {
        $holaDir = "Hola.php";
        return $holaDir;
    }

    

}