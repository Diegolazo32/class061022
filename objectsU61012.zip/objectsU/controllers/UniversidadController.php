<?php

class UniversidadController
{
    public function showUniversidad()
    {
        require_once "models/Universidad.php";
        $universidad = new Universidad();
        $showUniversidad = $universidad->showUniversidad();
        require_once "views/universidad.php";
    }
}