<?php

class UserController
{
    public function showUsers()
    {
        require_once "models/Users.php";
        $users = new Users();
        $showUsers = $users->showUsers();
        require_once "views/users.php";
    }
}



