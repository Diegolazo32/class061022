<?php

class HolaController
{
    public function showHola()
    {
    require_once "models/Hola.php";
    $Hola = new Hola();
    $showHola = $Hola->showHola();
    require_once "views/hola.php";

    }
}